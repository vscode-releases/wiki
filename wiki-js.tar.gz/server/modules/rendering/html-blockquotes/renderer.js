module.exports = {
  init($, config) {

  }
}
